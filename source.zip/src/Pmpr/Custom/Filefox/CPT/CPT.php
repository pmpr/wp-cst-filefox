<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Custom\Filefox\Container; class CPT extends Container { public function mameiwsayuyquoeq() { News::symcgieuakksimmu(); Product::symcgieuakksimmu(); } }

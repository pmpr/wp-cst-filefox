<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Custom\Filefox\Container; class CPT extends Container { public function mameiwsayuyquoeq() { News::symcgieuakksimmu(); Product::symcgieuakksimmu(); } }

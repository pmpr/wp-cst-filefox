<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7e2699c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Custom\Filefox\Container; class CPT extends Container { public function mameiwsayuyquoeq() { News::symcgieuakksimmu(); Product::symcgieuakksimmu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Common\Foundation\Interfaces\IconInterface; class News extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->acqyqaaeeogkosoq(self::qgciomgukmcwscqw)->muuwuqssqkaieqge(__("\x4e\145\167\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x54\150\x65\40\x4e\x65\x77\x73", PR__CST__FILEFOX))->yioesawwewqaigow(IconInterface::awmsmqouyuugigus); } }

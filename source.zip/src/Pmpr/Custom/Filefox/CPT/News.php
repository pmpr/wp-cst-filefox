<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009f65575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CPT; use Pmpr\Common\Foundation\Interfaces\IconInterface; class News extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->wakugsseussemkka([self::qescuiwgsyuikume, self::yaiacqocwcgmooio, self::syooqwmkmsmgwcqw, self::goumieeyyqigueiw, self::egwoacukmsioosum])->wiskakymeaywyeuw(true)->ckaeqgiaiqwsccke(6)->acqyqaaeeogkosoq(self::ocsomysosuqaimuc)->acqyqaaeeogkosoq(self::qgciomgukmcwscqw)->muuwuqssqkaieqge(__("\116\x65\167\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\124\x68\x65\40\116\145\x77\x73", PR__CST__FILEFOX))->yioesawwewqaigow(IconInterface::awmsmqouyuugigus); } }

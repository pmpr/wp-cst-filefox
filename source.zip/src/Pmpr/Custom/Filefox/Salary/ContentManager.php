<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977cbb169a2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary; use Pmpr\Module\Salary\AbstractSalary; class ContentManager extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = sprintf(__("\106\151\154\x65\106\157\170\x20\x43\x75\163\164\x6f\155\x20\50\x25\x73\51", PR__CST__FILEFOX), __("\x43\157\x6e\x74\x65\x6e\x74\x20\115\141\156\x61\147\x65\162", PR__CST__FILEFOX)); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } public function vaakeoqesyogieoe($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { } }

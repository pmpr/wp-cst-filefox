<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523b74ba2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Producer extends Member { public function register() { $this->saemoowcasogykak(IconInterface::mqiuasuykwwoiumy)->guiaswksukmgageq(__("\103\157\x6e\x74\x65\156\x74\x20\120\x72\157\144\165\x63\x65\162", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x43\157\156\164\145\x6e\x74\x20\x50\162\157\144\x75\143\x65\162\x73", PR__CST__FILEFOX))->uaywwyimkgwyqwya([Constants::yiuwgggacagyeqmo => 20]); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::mwisuqgywiccyykw)->gswweykyogmsyawy(__("\x54\x65\x61\155", PR__CST__FILEFOX))->wuuqgaekqeymecag(Team::class)); parent::uwmqacgewuauagai(); } }

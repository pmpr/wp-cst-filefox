<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd4758da1d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Salary\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Aggregate extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\101\147\x67\162\x65\147\x61\x74\x65\40\124\x72\141\146\146\151\x63", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\101\147\147\162\145\147\x61\164\145\40\x54\162\x61\146\146\x69\x63\x73", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(10); } }

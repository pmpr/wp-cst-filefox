<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac8591bd1e0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Feed extends Container { }

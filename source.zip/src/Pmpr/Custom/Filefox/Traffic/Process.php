<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb890f96f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\x66\x5f\x74\x72\141\x66\x66\151\143\x5f\152\157\142\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\145\164\x63\150\137\x70\x61\147\145\163\137\144\x61\x74\141"; public function ikcgmcycisiccyuc() { $this->group = "\146\x66\x5f\164\162\x61\146\x66\151\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\156\151\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }

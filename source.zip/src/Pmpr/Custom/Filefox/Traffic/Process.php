<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977cbb169a2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\x66\x5f\x74\162\x61\x66\146\x69\x63\137\x6a\157\142\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\164\x63\x68\137\x70\141\147\x65\163\137\x64\141\x74\x61"; public function ikcgmcycisiccyuc() { $this->group = "\x66\x66\x5f\x74\x72\141\x66\146\x69\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\x69\x67\x68\164"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }

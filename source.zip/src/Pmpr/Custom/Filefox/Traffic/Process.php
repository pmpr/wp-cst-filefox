<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523b74ba2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\x66\x66\x5f\164\162\141\146\x66\151\x63\x5f\x6a\157\142\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\146\145\164\143\150\137\160\x61\147\x65\x73\137\144\x61\164\141"; public function ikcgmcycisiccyuc() { $this->group = "\146\x66\x5f\x74\x72\x61\146\146\151\143"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\155\x69\x64\156\151\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da2a64aaa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const csqsymqoqwyowokg = "\146\x66\x5f\164\x72\141\x66\x66\151\143\x5f\x6a\157\142\137"; const iaoukeusekqewswc = self::csqsymqoqwyowokg . "\x66\x65\x74\x63\150\137\x70\x61\x67\x65\163\x5f\x64\141\x74\x61"; public function ikcgmcycisiccyuc() { $this->group = "\146\146\137\x74\162\141\x66\x66\151\x63"; } public function muoksumwiwiaouki() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\x6e\151\147\150\x74"), DAY_IN_SECONDS, self::iaoukeusekqewswc); } }

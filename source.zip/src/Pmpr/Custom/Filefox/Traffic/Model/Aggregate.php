<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67977cbb169a2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Traffic\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Aggregate extends Traffic { public function register() { $this->saemoowcasogykak(IconInterface::weyygumkwiqoimsu)->guiaswksukmgageq(__("\x41\147\147\162\x65\147\x61\x74\145\40\x54\162\x61\x66\x66\151\x63", PR__CST__FILEFOX))->muuwuqssqkaieqge(__("\x41\147\x67\x72\145\147\x61\164\x65\40\x54\162\x61\146\x66\151\x63\163", PR__CST__FILEFOX)); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->uqeoyqiwywwmsiew(Constants::qiyqwyiiwykeccmo)->acceqyqygswoecwe(10); } }

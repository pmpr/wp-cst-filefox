<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d3e96e3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; use Pmpr\Custom\Filefox\Salary\Salary; use Pmpr\Module\Panel\REST\AbstractREST; abstract class Controller extends AbstractREST { public function __construct() { $this->abstract = true; parent::__construct(); $this->namespace .= "\x2f\143\x6f\156\x74\145\156\164"; } public function emwagqamysmyeigc($mkucggyaiaukqoce) : bool { return $this->caokeucsksukesyo()->issssuygyewuaswa()->askmkgcmgekiqwsg(Salary::icygkcucieasceuk, $mkucggyaiaukqoce, true); } public function mgawqagyqukmasom($mkucggyaiaukqoce) : bool { return $this->caokeucsksukesyo()->issssuygyewuaswa()->askmkgcmgekiqwsg(Salary::emceseoyeswkikuu, $mkucggyaiaukqoce, true); } public function iugaygkgyqmwqmus() : bool { } }

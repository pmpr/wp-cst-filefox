<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d3e96e3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class Team extends Controller { }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd4758da1d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = "\x63\157\x6e\x74\145\156\164\x2d\155\x61\156\x61\x67\x65\155\145\156\164"; parent::__construct(); } }

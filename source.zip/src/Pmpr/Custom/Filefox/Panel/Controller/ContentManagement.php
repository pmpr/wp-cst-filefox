<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e71656             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel\Controller; class ContentManagement extends Controller { public function __construct() { $this->rest_base = "\x63\157\x6e\x74\x65\156\x74\55\x6d\141\156\141\x67\x65\x6d\145\156\164"; parent::__construct(); } }

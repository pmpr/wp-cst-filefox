<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71d1b0f27             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Panel; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c461fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Custom\Filefox\Frontend\Page\Common as BaseClass; abstract class Common extends BaseClass { public function __construct() { $this->parent = Request::symcgieuakksimmu(); $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } }

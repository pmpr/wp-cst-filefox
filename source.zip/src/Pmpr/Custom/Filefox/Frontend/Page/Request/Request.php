<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523b74ba2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Setting\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qgeesceacsmeqacu)->gswweykyogmsyawy(__("\x52\x65\x71\165\x65\x73\164", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wiqyuskqsguiamau)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb890f96f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Setting\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qgeesceacsmeqacu)->gswweykyogmsyawy(__("\122\x65\x71\x75\x65\163\164", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::wiqyuskqsguiamau)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Custom\Filefox\Frontend\Page\Common; class Request extends Common { public function __construct() { $this->slug = self::qgeesceacsmeqacu; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\145\x71\x75\145\x73\x74", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Custom\Filefox\Frontend\Page\Common; class Request extends Common { public function __construct() { $this->slug = self::qgeesceacsmeqacu; $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\x65\161\x75\x65\163\x74", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

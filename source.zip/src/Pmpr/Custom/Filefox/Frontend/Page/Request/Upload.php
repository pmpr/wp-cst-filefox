<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56af5ccaf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Upload extends Common { public function __construct() { $this->slug = self::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x50\x72\x6f\x76\x69\x64\145\x20\x46\x69\x6c\x65", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

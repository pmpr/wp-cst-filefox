<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce115460383             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; class Upload extends Common { public function __construct() { $this->slug = Constants::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\120\162\x6f\x76\x69\144\x65\40\106\151\x6c\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

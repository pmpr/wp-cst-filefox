<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Upload extends Common { public function __construct() { $this->slug = self::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\120\x72\x6f\166\x69\144\x65\x20\106\151\x6c\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

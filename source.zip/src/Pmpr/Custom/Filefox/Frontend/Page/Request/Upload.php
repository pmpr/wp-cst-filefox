<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009f65575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Upload extends Common { public function __construct() { $this->slug = self::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\120\x72\x6f\x76\151\144\x65\x20\106\x69\154\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030cf0d2fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Custom\Filefox\Setting; class Upload extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw(Constants::qikaiaaocseouyaw)->gswweykyogmsyawy(__("\x50\x72\x6f\166\151\x64\145\40\106\x69\x6c\x65", PR__CST__FILEFOX))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::uqeikoymiywauawa)); } }

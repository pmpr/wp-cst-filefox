<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Upload extends Common { public function __construct() { $this->slug = self::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x50\162\x6f\x76\151\x64\x65\x20\106\151\154\x65", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

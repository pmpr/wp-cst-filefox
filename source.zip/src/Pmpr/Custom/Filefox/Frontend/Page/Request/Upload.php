<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Upload extends Common { public function __construct() { $this->slug = self::qikaiaaocseouyaw; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\120\162\x6f\166\x69\x64\x65\x20\x46\x69\154\x65", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\122\145\161\x75\x65\x73\164\40\x46\151\154\x65", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\164\162\x61\x63\153\x5f\164\151\x74\154\x65" => __("\124\x72\141\x63\x6b\x20\x52\145\x71\165\x65\163\164", PR__CST__FILEFOX), "\164\162\x61\143\x6b\x5f\x61\143\164\x69\x6f\156" => "\x66\x66\x5f\164\x69\x63\153\x65\164\x5f\x67\x65\164\x5f\164\x72\x61\143\x6b\137\x66\x6f\162\x6d", "\x73\165\142\155\x69\x74\137\x74\151\x74\x6c\x65" => __("\123\165\142\155\x69\x74\40\122\x65\x71\165\145\x73\x74", PR__CST__FILEFOX), "\163\165\142\x6d\151\164\x5f\141\x63\164\151\x6f\x6e" => "\146\146\137\164\151\143\x6b\x65\164\137\147\x65\x74\x5f\x66\151\154\x65\x5f\162\145\161\165\145\163\x74\x5f\146\157\162\x6d"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\x69\x63\153\145\164\x5f\145\156\161\165\145\x75\145\x5f\146\x6f\x72\x6d\x5f\141\x73\x73\145\164\163"); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\122\145\161\x75\x65\x73\164\x20\106\x69\154\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\x74\162\141\x63\153\137\164\151\x74\154\x65" => __("\x54\x72\x61\143\x6b\40\x52\x65\x71\x75\145\x73\x74", PR__CST__FILEFOX), "\164\162\141\143\153\137\141\143\164\151\x6f\156" => "\146\146\x5f\x74\x69\143\x6b\x65\x74\137\x67\145\164\137\164\x72\x61\143\153\137\146\x6f\x72\x6d", "\x73\165\142\x6d\151\164\137\x74\151\164\154\x65" => __("\123\x75\x62\155\x69\x74\40\122\x65\161\165\145\163\164", PR__CST__FILEFOX), "\163\165\142\x6d\151\164\x5f\141\x63\164\151\x6f\156" => "\146\x66\x5f\164\x69\143\x6b\145\x74\137\x67\145\164\137\x66\x69\x6c\145\137\162\145\161\x75\x65\x73\x74\137\x66\157\162\155"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\151\143\x6b\x65\164\x5f\145\156\x71\165\x65\x75\145\x5f\x66\157\x72\x6d\137\141\163\x73\145\164\x73"); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\145\x71\165\x65\163\x74\x20\x46\151\x6c\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\x74\x72\141\143\x6b\x5f\x74\x69\164\154\145" => __("\x54\x72\x61\143\x6b\x20\122\x65\x71\x75\x65\163\164", PR__CST__FILEFOX), "\164\162\141\x63\x6b\x5f\x61\143\164\151\157\x6e" => "\x66\x66\137\164\151\143\x6b\145\164\137\x67\145\164\137\x74\x72\x61\x63\x6b\137\146\x6f\162\155", "\x73\x75\142\x6d\x69\164\x5f\x74\x69\x74\154\145" => __("\123\x75\142\x6d\x69\164\40\x52\145\x71\165\x65\x73\164", PR__CST__FILEFOX), "\163\x75\142\x6d\x69\164\137\141\143\164\x69\x6f\x6e" => "\x66\146\137\164\x69\143\153\145\x74\x5f\147\x65\164\137\x66\151\154\145\x5f\162\145\161\165\x65\x73\164\137\146\157\x72\155"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\x69\143\x6b\145\x74\x5f\x65\x6e\161\165\x65\x75\x65\x5f\146\157\x72\155\137\141\163\163\x65\x74\163"); } }

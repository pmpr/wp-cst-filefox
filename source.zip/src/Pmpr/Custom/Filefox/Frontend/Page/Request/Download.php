<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\145\x71\165\x65\x73\x74\x20\x46\x69\x6c\x65", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\x74\162\141\x63\153\137\164\x69\x74\154\145" => __("\124\162\141\x63\x6b\40\122\x65\161\x75\x65\x73\164", PR__CST__FILEFOX), "\x74\x72\x61\143\x6b\137\141\x63\164\151\x6f\x6e" => "\x66\x66\137\x74\x69\x63\x6b\145\x74\137\147\145\164\137\x74\x72\x61\143\153\x5f\146\157\x72\x6d", "\163\165\142\155\x69\164\x5f\164\x69\164\154\145" => __("\123\165\x62\155\x69\164\40\122\x65\x71\165\x65\x73\164", PR__CST__FILEFOX), "\x73\x75\x62\x6d\x69\x74\137\141\143\x74\151\157\x6e" => "\146\x66\137\164\151\x63\x6b\x65\x74\x5f\147\x65\x74\x5f\x66\151\154\145\x5f\162\145\x71\x75\145\163\164\137\x66\157\162\x6d"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\151\x63\153\145\x74\x5f\145\x6e\x71\165\x65\x75\x65\x5f\x66\x6f\x72\x6d\x5f\141\x73\x73\145\164\x73"); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56af5ccaf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\122\145\x71\165\145\x73\x74\40\x46\151\x6c\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\164\162\x61\143\x6b\137\x74\151\x74\154\x65" => __("\x54\162\x61\143\153\40\x52\x65\x71\x75\145\x73\x74", PR__CST__FILEFOX), "\x74\162\x61\x63\153\137\x61\143\x74\151\157\156" => "\146\x66\x5f\x74\151\143\153\145\x74\137\x67\x65\164\137\164\162\x61\143\x6b\137\x66\x6f\x72\x6d", "\163\165\142\x6d\151\164\x5f\164\151\164\154\x65" => __("\123\165\x62\155\x69\164\x20\122\x65\161\165\145\x73\x74", PR__CST__FILEFOX), "\163\165\142\x6d\x69\x74\x5f\141\143\x74\151\157\156" => "\x66\146\137\x74\151\143\x6b\145\x74\137\x67\145\x74\137\146\151\x6c\x65\x5f\x72\145\x71\165\145\163\x74\137\x66\x6f\x72\x6d"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\x69\143\153\145\x74\x5f\145\156\161\165\145\x75\145\137\x66\157\162\x6d\137\141\x73\x73\x65\x74\163"); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfb011a73             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\122\145\161\x75\145\x73\164\x20\x46\x69\154\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\164\162\141\143\x6b\x5f\164\x69\x74\154\145" => __("\x54\x72\x61\x63\153\40\122\145\161\165\145\163\164", PR__CST__FILEFOX), "\164\162\x61\143\x6b\137\x61\x63\x74\151\x6f\x6e" => "\146\146\137\x74\151\143\x6b\145\164\x5f\x67\x65\164\137\x74\162\x61\143\x6b\x5f\x66\157\x72\x6d", "\x73\x75\142\155\151\x74\x5f\x74\x69\x74\x6c\145" => __("\123\165\142\x6d\151\x74\x20\x52\145\x71\x75\145\x73\x74", PR__CST__FILEFOX), "\x73\165\142\155\151\x74\137\x61\x63\164\x69\157\156" => "\x66\146\137\x74\151\143\x6b\145\x74\x5f\x67\x65\164\137\146\x69\154\x65\137\x72\x65\161\x75\145\x73\164\137\146\157\x72\155"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\x69\x63\153\x65\x74\x5f\x65\x6e\x71\x75\x65\x75\x65\137\x66\157\x72\155\x5f\141\x73\163\x65\164\163"); } }

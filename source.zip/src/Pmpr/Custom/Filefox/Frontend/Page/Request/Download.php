<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page\Request; class Download extends Common { public function __construct() { $this->slug = self::kucuwimmakgiieom; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x52\145\161\x75\145\163\164\40\106\x69\x6c\145", PR__CST__FILEFOX); parent::gogaagekwoisaqgu(); } public function rsysgcucogueguuk() : array { return ["\x74\162\141\143\x6b\x5f\x74\x69\x74\154\145" => __("\x54\162\141\143\153\x20\x52\x65\161\x75\x65\163\164", PR__CST__FILEFOX), "\164\x72\141\x63\x6b\x5f\141\143\x74\x69\157\156" => "\x66\146\137\164\x69\x63\x6b\145\x74\x5f\147\145\x74\137\164\162\141\x63\x6b\x5f\146\157\x72\155", "\x73\165\142\155\x69\x74\137\164\x69\164\154\145" => __("\x53\x75\x62\x6d\151\x74\x20\122\x65\x71\x75\145\163\x74", PR__CST__FILEFOX), "\x73\x75\142\x6d\151\x74\x5f\141\x63\164\x69\157\x6e" => "\146\x66\137\164\x69\x63\153\145\x74\x5f\147\145\x74\137\146\151\154\145\137\162\145\161\165\x65\x73\x74\137\146\x6f\x72\155"]; } public function enqueue() { $this->ewcsyqaaigkicgse("\164\151\143\x6b\x65\x74\x5f\x65\x6e\x71\x75\145\x75\x65\137\x66\157\162\155\137\141\x73\x73\x65\x74\163"); } }

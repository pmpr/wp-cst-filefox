<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86629acc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page; use Pmpr\Custom\Filefox\Frontend\Common; use Pmpr\Custom\Filefox\Frontend\Page\Request\Request; use Pmpr\Custom\Filefox\Frontend\Page\Request\Upload; use Pmpr\Custom\Filefox\Frontend\Page\Request\Download as RequestDownload; class Page extends Common { public function mameiwsayuyquoeq() { Upload::symcgieuakksimmu(); Request::symcgieuakksimmu(); Download::symcgieuakksimmu(); RequestDownload::symcgieuakksimmu(); } }

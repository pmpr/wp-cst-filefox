<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Filefox\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }

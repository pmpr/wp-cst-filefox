<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Filefox\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }

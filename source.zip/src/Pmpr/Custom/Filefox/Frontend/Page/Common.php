<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend\Page; use Pmpr\Common\Foundation\Page\Page; use Pmpr\Custom\Filefox\Interfaces\CommonInterface; abstract class Common extends Page implements CommonInterface { }

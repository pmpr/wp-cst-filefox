<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56af5ccaf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { }

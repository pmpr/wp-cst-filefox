<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a90c63fb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend; use Pmpr\Custom\Filefox\Frontend\Page\Page; class Frontend extends Common { public function mameiwsayuyquoeq() { Ajax::symcgieuakksimmu(); Page::symcgieuakksimmu(); } }

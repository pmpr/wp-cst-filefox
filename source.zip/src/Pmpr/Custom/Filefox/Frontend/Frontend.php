<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfb011a73             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Frontend; use Pmpr\Custom\Filefox\Frontend\Page\Page; class Frontend extends Common { public function mameiwsayuyquoeq() { Ajax::symcgieuakksimmu(); Page::symcgieuakksimmu(); } }

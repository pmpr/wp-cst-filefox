<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56af5ccaf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Single::symcgieuakksimmu(); } }

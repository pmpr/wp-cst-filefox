<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Single::symcgieuakksimmu(); } }

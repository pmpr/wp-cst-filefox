<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe450cfd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage\Model; use Pmpr\Custom\Filefox\Container; class Model extends Container { public function mameiwsayuyquoeq() { Account::symcgieuakksimmu(); Replica::symcgieuakksimmu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfb011a73             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage\Model; use Pmpr\Custom\Filefox\Container; class Model extends Container { public function mameiwsayuyquoeq() { Account::symcgieuakksimmu(); Replica::symcgieuakksimmu(); } }

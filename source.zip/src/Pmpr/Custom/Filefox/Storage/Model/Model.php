<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage\Model; use Pmpr\Custom\Filefox\Container; class Model extends Container { public function mameiwsayuyquoeq() { Account::symcgieuakksimmu(); Replica::symcgieuakksimmu(); } }

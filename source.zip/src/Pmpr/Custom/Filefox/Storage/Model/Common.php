<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage\Model; use Pmpr\Common\Foundation\ORM\DB\Model as BaseClass; use Pmpr\Custom\Filefox\Interfaces\CommonInterface; abstract class Common extends BaseClass implements CommonInterface { public function ckgmycmaukqgkosk() { $wksoawcgagcgoask = self::akuociswqmoigkas(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->okgmqaeuaeymaocm($wksoawcgagcgoask)->wiskakymeaywyeuw($wksoawcgagcgoask); parent::ckgmycmaukqgkosk(); } }

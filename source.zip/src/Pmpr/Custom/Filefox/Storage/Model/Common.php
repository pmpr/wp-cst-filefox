<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7e2699c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage\Model; use Pmpr\Common\Foundation\ORM\Model; abstract class Common extends Model { }

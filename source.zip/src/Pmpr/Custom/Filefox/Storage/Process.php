<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage; class Process { }

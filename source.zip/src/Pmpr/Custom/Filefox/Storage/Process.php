<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfb011a73             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage; class Process { }

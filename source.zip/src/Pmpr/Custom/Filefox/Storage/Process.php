<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Storage; class Process { }

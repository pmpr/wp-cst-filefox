<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd7e2699c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\x6c\145\x5f\162\x65\161\165\x65\x73\164"; const suooagqkicoeawcy = "\x66\x69\154\x65\137\x70\x72\157\x76\151\x64\x65"; }

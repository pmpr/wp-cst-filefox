<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009f65575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\145\x5f\162\145\161\x75\145\x73\164"; const suooagqkicoeawcy = "\146\x69\x6c\x65\137\160\162\157\166\x69\x64\x65"; }

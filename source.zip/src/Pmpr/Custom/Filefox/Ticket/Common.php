<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\x6c\145\137\162\145\x71\165\145\163\164"; const suooagqkicoeawcy = "\x66\x69\x6c\x65\137\x70\x72\x6f\166\x69\144\145"; }

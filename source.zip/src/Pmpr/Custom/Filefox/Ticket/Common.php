<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\145\137\162\145\161\x75\x65\163\x74"; const suooagqkicoeawcy = "\x66\x69\154\145\x5f\x70\x72\x6f\166\151\144\145"; }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b52dd85             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\154\x65\x5f\162\x65\x71\165\145\163\164"; const suooagqkicoeawcy = "\146\x69\154\145\x5f\160\162\x6f\x76\x69\144\x65"; }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e71656             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\x6c\x65\137\162\x65\x71\x75\145\163\x74"; const suooagqkicoeawcy = "\146\151\154\x65\x5f\x70\x72\157\x76\x69\144\x65"; }

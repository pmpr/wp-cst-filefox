<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb890f96f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\x65\x5f\162\x65\x71\x75\145\x73\x74"; const suooagqkicoeawcy = "\x66\x69\x6c\145\x5f\160\162\x6f\166\151\144\x65"; }

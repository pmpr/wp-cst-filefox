<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce115460383             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\154\x65\x5f\x72\145\161\165\x65\163\x74"; const suooagqkicoeawcy = "\146\x69\154\x65\137\x70\162\157\x76\151\x64\x65"; }

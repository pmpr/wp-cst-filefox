<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\x65\x5f\x72\x65\161\165\145\x73\164"; const suooagqkicoeawcy = "\146\151\x6c\x65\137\x70\x72\x6f\166\x69\x64\x65"; }

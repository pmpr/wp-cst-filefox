<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd4758da1d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\x6c\x65\x5f\x72\145\x71\165\145\x73\164"; const suooagqkicoeawcy = "\146\x69\154\145\x5f\160\162\x6f\166\151\144\x65"; }

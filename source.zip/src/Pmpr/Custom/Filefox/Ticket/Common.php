<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9ff18bdca             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\151\154\145\137\162\x65\x71\165\x65\163\x74"; const suooagqkicoeawcy = "\x66\x69\x6c\x65\x5f\x70\x72\157\166\x69\144\x65"; }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfb011a73             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\x6c\x65\x5f\x72\x65\x71\165\145\163\164"; const suooagqkicoeawcy = "\x66\x69\x6c\x65\137\x70\x72\157\x76\x69\144\x65"; }

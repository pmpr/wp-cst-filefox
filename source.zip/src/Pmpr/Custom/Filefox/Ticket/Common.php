<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523b74ba2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\154\145\137\x72\145\161\165\x65\163\164"; const suooagqkicoeawcy = "\x66\151\154\145\137\x70\162\x6f\166\151\x64\x65"; }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d41004a282             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\x69\154\145\137\162\145\161\x75\145\x73\164"; const suooagqkicoeawcy = "\x66\x69\154\x65\137\x70\x72\x6f\x76\151\x64\145"; }

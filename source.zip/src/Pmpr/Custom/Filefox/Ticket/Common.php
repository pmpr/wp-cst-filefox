<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da2a64aaa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\146\151\154\x65\x5f\x72\145\161\x75\145\x73\x74"; const suooagqkicoeawcy = "\x66\151\x6c\145\x5f\x70\162\157\166\x69\x64\145"; }

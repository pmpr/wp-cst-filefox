<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffd25ef2f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\Ticket; use Pmpr\Custom\Filefox\Container; abstract class Common extends Container { const gewoiiswcuiwggqo = "\x66\x69\154\145\137\162\145\x71\165\145\x73\164"; const suooagqkicoeawcy = "\146\x69\154\145\137\160\162\x6f\x76\151\x64\145"; }

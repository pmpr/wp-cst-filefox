<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a90c63fb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\146\x6f\162\x65\x5f\145\156\161\x75\145\x75\x65\137\x62\141\143\153\145\156\x64\x5f\x61\163\163\145\x74\x73", [$this, "\145\156\x71\165\145\x75\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\x61\x63\x6b\145\156\144", $eygsasmqycagyayw->get("\x62\x61\x63\153\x65\156\144\56\152\x73"))->simswskycwagoeqy()); } }

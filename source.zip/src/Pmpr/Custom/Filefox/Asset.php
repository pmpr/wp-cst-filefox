<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfb011a73             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\x5f\x69\x6e\x69\x74", [$this, "\x65\x6e\161\x75\145\165\145"]); } public function enqueue() { $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto cgiscsqwwgqqaeqi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\x61\143\x6b\145\x6e\144", $eygsasmqycagyayw->get("\x62\141\143\153\x65\x6e\x64\x2e\152\163"))->simswskycwagoeqy()); cgiscsqwwgqqaeqi: } }

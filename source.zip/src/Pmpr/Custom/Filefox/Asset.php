<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe450cfd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\x6f\x72\145\137\x65\x6e\x71\x75\145\x75\x65\137\x62\x61\143\153\x65\156\144\x5f\x61\163\163\x65\x74\x73", [$this, "\x65\156\x71\165\x65\x75\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\x61\143\153\145\156\x64", $eygsasmqycagyayw->get("\x62\141\x63\153\x65\x6e\144\56\152\163"))->simswskycwagoeqy()); } }

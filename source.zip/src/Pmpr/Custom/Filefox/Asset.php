<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\156\137\x69\x6e\x69\x74", [$this, "\x65\x6e\x71\x75\x65\x75\145"]); } public function enqueue() { $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto meawswgwagoqgkye; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\142\x61\x63\153\x65\x6e\144", $eygsasmqycagyayw->get("\142\x61\x63\153\145\156\x64\56\152\x73"))->simswskycwagoeqy()); meawswgwagoqgkye: } }

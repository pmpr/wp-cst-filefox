<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\137\151\x6e\151\164", [$this, "\x65\x6e\x71\165\145\165\145"]); } public function enqueue() { $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto cecuyayqoioasumi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\142\141\143\x6b\145\156\144", $eygsasmqycagyayw->get("\142\x61\143\153\145\x6e\144\56\152\163"))->simswskycwagoeqy()); cecuyayqoioasumi: } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\x6e\x5f\x69\156\151\x74", [$this, "\145\x6e\x71\165\145\x75\x65"]); } public function enqueue() { $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto cecuyayqoioasumi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\142\141\x63\x6b\x65\156\144", $eygsasmqycagyayw->get("\142\141\143\x6b\x65\x6e\144\x2e\152\x73"))->simswskycwagoeqy()); cecuyayqoioasumi: } }

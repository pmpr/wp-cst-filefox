<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86629acc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\157\162\145\137\x65\156\x71\165\x65\165\145\137\142\x61\x63\153\x65\x6e\144\x5f\141\x73\x73\145\164\163", [$this, "\x65\x6e\x71\x75\x65\x75\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\x61\143\153\x65\x6e\144", $eygsasmqycagyayw->get("\x62\x61\x63\x6b\x65\x6e\144\56\152\163"))->simswskycwagoeqy()); } }

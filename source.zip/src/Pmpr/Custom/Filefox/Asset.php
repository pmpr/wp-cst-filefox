<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c461fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\162\x65\137\145\x6e\x71\x75\x65\x75\145\137\x62\x61\x63\x6b\145\x6e\144\137\x61\x73\x73\145\164\x73", [$this, "\145\156\x71\165\x65\x75\145"]); } public function enqueue() { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->qeqgammgesiwiysc($meakksicouekcgoe->owygwqwawqoiusis($this, "\142\x61\x63\153\145\156\144", "\x62\x61\x63\153\x65\x6e\x64\56\x6a\163")->simswskycwagoeqy()); } }

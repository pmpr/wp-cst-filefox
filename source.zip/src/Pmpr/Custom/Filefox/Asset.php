<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009f65575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\156\x5f\x69\156\151\x74", [$this, "\145\156\161\x75\145\165\x65"]); } public function enqueue() { $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto mkwskuycuyguqqok; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x62\x61\143\153\x65\x6e\x64", $eygsasmqycagyayw->get("\x62\x61\x63\153\145\x6e\x64\x2e\x6a\x73"))->simswskycwagoeqy()); mkwskuycuyguqqok: } }

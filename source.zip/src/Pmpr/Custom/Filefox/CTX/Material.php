<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe450cfd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\x61\x74\x65\x72\151\x61\154\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x61\x74\x65\162\151\141\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\141\164\145\162\x69\x61\x6c\x20\146\x6f\162\40\x70\x72\x6f\144\x75\143\x74\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\115\145\x64\151\165\x6d", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }

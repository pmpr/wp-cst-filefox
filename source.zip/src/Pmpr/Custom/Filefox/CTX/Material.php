<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffd25ef2f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x61\x74\x65\x72\151\141\x6c\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x61\164\145\162\x69\141\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\x61\x74\x65\162\x69\141\x6c\40\146\157\162\40\160\x72\157\x64\x75\x63\164\163", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__("\x4d\145\144\151\165\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka())->mkksewyosgeumwsa($uuyucgkyusckoaeq->gosycecgwuesyysq(Constants::qgqyauaqwqmqseim)->gswweykyogmsyawy(__("\111\x63\157\156", PR__CST__FILEFOX))); } }

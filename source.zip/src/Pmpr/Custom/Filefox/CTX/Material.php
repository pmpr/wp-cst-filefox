<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\141\164\x65\162\x69\x61\154\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x61\x74\145\x72\x69\141\154", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\141\164\x65\x72\x69\141\154\40\146\x6f\x72\40\x70\x72\157\x64\165\x63\164\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::MEDIUM)->gswweykyogmsyawy(__("\x4d\x65\x64\151\x75\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(self::yoayaissyomokiui, self::MEDIUM, [self::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\141\164\x65\162\151\x61\x6c\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\141\x74\x65\x72\151\x61\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\141\164\145\162\x69\141\x6c\40\146\157\x72\40\x70\162\x6f\x64\x75\143\164\163", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::MEDIUM)->gswweykyogmsyawy(__("\x4d\145\144\x69\x75\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(self::yoayaissyomokiui, self::MEDIUM, [self::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56af5ccaf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\141\164\145\x72\x69\141\x6c\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x61\164\145\162\151\141\x6c", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\141\164\145\162\151\x61\154\40\146\157\162\x20\x70\x72\157\144\x75\143\164\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::MEDIUM)->gswweykyogmsyawy(__("\115\x65\x64\x69\165\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(self::yoayaissyomokiui, self::MEDIUM, [self::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }

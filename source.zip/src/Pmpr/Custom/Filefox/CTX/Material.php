<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Material extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x61\x74\x65\x72\151\x61\x6c\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x61\164\145\x72\151\141\154", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\141\x74\145\162\151\x61\154\40\x66\157\x72\40\160\162\157\144\165\143\164\x73", PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::MEDIUM)->gswweykyogmsyawy(__("\x4d\145\144\x69\x75\155", PR__CST__FILEFOX))->yqoayqwisqmuomom(self::yoayaissyomokiui, self::MEDIUM, [self::mkucwyayaakigquq => false])->oikgogcweiiaocka()); } }

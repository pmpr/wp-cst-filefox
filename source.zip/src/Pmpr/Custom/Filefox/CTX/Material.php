<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9ebfdf2e77             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Material extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->wsekoqmcyeuyegam()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->kukswgcoysaeescm(Constants::sususqikkuaoqeco)->muuwuqssqkaieqge(__('Materials', PR__CST__FILEFOX))->guiaswksukmgageq(__('Material', PR__CST__FILEFOX))->gucwmccyimoagwcm(__('Material for products', PR__CST__FILEFOX)); } public function aoqwywcqmoqaukkq() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::MEDIUM)->gswweykyogmsyawy(__('Medium', PR__CST__FILEFOX))->yqoayqwisqmuomom(Constants::yoayaissyomokiui, Constants::MEDIUM, [Constants::mkucwyayaakigquq => false])->oikgogcweiiaocka())->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws('search_placeholder')->gswweykyogmsyawy(__('Search Placeholder', PR__CST__FILEFOX)))->mkksewyosgeumwsa($uuyucgkyusckoaeq->gosycecgwuesyysq(Constants::qgqyauaqwqmqseim)->gswweykyogmsyawy(__('Icon', PR__CST__FILEFOX))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Custom\Filefox\Interfaces\CommonInterface; abstract class Common extends CTX implements CommonInterface { }

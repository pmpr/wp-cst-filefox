<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d3e96e3d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\144\x69\165\155\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\145\x64\151\165\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\145\144\151\165\x6d\x20\146\157\x72\40\x70\162\157\144\x75\x63\164\163", PR__CST__FILEFOX)); } }

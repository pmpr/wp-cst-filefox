<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd4758da1d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\144\151\x75\155\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\145\x64\151\x75\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\145\144\151\x75\155\x20\146\x6f\x72\40\x70\162\x6f\144\165\x63\164\x73", PR__CST__FILEFOX)); } }

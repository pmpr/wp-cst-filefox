<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c461fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x65\x64\151\x75\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\145\x64\151\x75\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x65\x64\x69\165\x6d\40\x66\x6f\x72\40\x70\x72\157\144\x75\x63\164\x73", PR__CST__FILEFOX)); } }

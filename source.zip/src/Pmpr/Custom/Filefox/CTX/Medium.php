<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\x64\x69\165\x6d\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\145\144\x69\165\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\145\x64\151\x75\x6d\x20\x66\157\162\40\x70\162\157\x64\165\x63\164\x73", PR__CST__FILEFOX)); } }

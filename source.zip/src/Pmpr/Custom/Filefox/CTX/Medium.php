<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\144\151\165\155\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x65\144\151\x75\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\x65\144\x69\x75\155\x20\x66\157\162\x20\x70\x72\x6f\144\x75\143\x74\163", PR__CST__FILEFOX)); } }

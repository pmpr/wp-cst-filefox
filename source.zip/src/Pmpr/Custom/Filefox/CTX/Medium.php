<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe450cfd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\145\144\151\165\x6d\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\145\144\151\x75\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\x65\144\x69\x75\x6d\40\146\x6f\162\x20\x70\162\157\x64\x75\143\x74\x73", PR__CST__FILEFOX)); } }

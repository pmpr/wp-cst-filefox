<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009f65575             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\x65\144\151\x75\x6d\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\145\x64\151\x75\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\x65\x64\x69\x75\x6d\x20\x66\x6f\x72\x20\x70\162\x6f\144\165\143\164\163", PR__CST__FILEFOX)); } }

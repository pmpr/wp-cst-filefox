<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Medium extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\x65\x64\x69\x75\155\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x4d\x65\x64\151\x75\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x4d\145\x64\x69\x75\x6d\40\x66\157\x72\40\x70\162\157\144\165\x63\164\x73", PR__CST__FILEFOX)); } }

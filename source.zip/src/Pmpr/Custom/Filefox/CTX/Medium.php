<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9ff18bdca             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x4d\145\x64\151\165\155\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\145\x64\x69\165\155", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\145\x64\151\x75\x6d\x20\x66\x6f\x72\x20\160\162\x6f\x64\165\143\x74\163", PR__CST__FILEFOX)); } }

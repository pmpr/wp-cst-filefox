<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b52dd85             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Medium extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\115\145\144\x69\x75\155\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\115\x65\144\x69\165\x6d", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\115\x65\144\x69\165\155\x20\x66\157\x72\40\160\162\157\144\165\x63\x74\163", PR__CST__FILEFOX)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56af5ccaf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\160\154\x69\143\x61\164\x69\157\x6e\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\x70\x6c\151\143\141\x74\x69\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\156\x20\146\x6f\x72\40\x70\x72\x6f\144\x75\x63\164\x73", PR__CST__FILEFOX)); } }

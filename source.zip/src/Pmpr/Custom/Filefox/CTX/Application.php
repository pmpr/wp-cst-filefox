<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1ec2d1d35             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\160\x6c\151\x63\141\164\x69\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\160\x6c\x69\143\141\164\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\x70\x6c\151\x63\x61\x74\151\157\x6e\40\146\x6f\162\x20\x70\x72\x6f\144\x75\x63\164\x73", PR__CST__FILEFOX)); } }

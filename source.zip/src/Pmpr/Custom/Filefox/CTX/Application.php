<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058753c091c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\x70\x70\x6c\151\x63\x61\x74\151\157\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\x70\x6c\151\x63\x61\x74\x69\x6f\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\160\x70\x6c\151\143\x61\164\x69\157\156\x20\x66\157\162\40\x70\162\157\144\x75\x63\164\163", PR__CST__FILEFOX)); } }

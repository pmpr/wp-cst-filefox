<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffd25ef2f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\x70\x6c\x69\143\x61\x74\151\x6f\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\x70\x6c\151\143\x61\164\x69\x6f\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\x70\154\x69\x63\x61\x74\151\x6f\x6e\x20\x66\157\162\40\x70\162\x6f\144\165\143\164\163", PR__CST__FILEFOX)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c461fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\x70\x6c\151\143\x61\164\151\157\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\x70\x6c\x69\143\141\x74\x69\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\x70\x70\x6c\x69\143\x61\164\151\x6f\156\40\x66\x6f\162\x20\160\x72\x6f\x64\165\x63\164\163", PR__CST__FILEFOX)); } }

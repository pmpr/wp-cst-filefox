<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d10b8fa             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\160\x6c\151\143\x61\x74\151\157\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\x70\154\151\143\141\x74\x69\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\x70\x70\154\x69\x63\141\164\151\x6f\156\40\x66\157\x72\x20\160\x72\157\x64\x75\x63\164\x73", PR__CST__FILEFOX)); } }

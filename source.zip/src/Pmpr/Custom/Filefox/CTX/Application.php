<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86629acc             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\x70\x6c\151\143\x61\164\x69\x6f\156\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\160\x6c\x69\x63\x61\164\151\x6f\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\x70\154\151\143\x61\164\151\x6f\x6e\40\x66\157\162\40\160\162\157\x64\165\x63\x74\x73", PR__CST__FILEFOX)); } }

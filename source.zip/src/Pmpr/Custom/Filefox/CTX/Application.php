<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce8e71656             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\160\154\x69\143\141\164\x69\157\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\160\160\154\151\x63\x61\164\x69\x6f\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\160\x6c\151\x63\141\x74\x69\x6f\x6e\40\146\157\162\x20\160\x72\x6f\x64\165\143\x74\163", PR__CST__FILEFOX)); } }

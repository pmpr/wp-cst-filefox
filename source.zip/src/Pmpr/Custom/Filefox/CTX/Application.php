<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1e346ba59             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\160\x6c\151\143\x61\164\x69\x6f\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\160\160\x6c\151\x63\141\164\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\160\x6c\151\143\141\164\x69\x6f\x6e\x20\x66\x6f\x72\x20\x70\162\x6f\x64\165\143\x74\163", PR__CST__FILEFOX)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a90c63fb             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\x70\160\x6c\151\143\141\x74\151\x6f\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\x41\x70\160\x6c\x69\143\x61\x74\151\157\x6e", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\160\154\x69\143\x61\164\151\x6f\x6e\x20\146\x6f\162\x20\x70\162\x6f\x64\165\x63\164\163", PR__CST__FILEFOX)); } }

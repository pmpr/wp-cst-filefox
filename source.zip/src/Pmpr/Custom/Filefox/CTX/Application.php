<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb890f96f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\160\x6c\x69\x63\141\164\151\157\156\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\x70\154\151\143\141\164\x69\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\x70\160\x6c\x69\143\x61\x74\x69\x6f\156\x20\146\157\162\x20\160\x72\x6f\144\165\143\164\163", PR__CST__FILEFOX)); } }

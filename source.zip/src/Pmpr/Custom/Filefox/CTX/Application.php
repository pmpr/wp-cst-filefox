<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523b74ba2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; class Application extends CTX { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(Constants::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\101\160\x70\154\x69\x63\x61\164\x69\x6f\156\x73", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\x70\x6c\151\143\141\x74\x69\x6f\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\x41\160\x70\x6c\151\x63\141\x74\151\157\x6e\x20\146\x6f\162\x20\160\x72\x6f\144\x75\143\164\163", PR__CST__FILEFOX)); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86dd3f86             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; class Application extends Common { public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ogacomococeeqame()->ickqomquaqgqywkw(true)->kukswgcoysaeescm(self::oguseymmyyoyaako)->muuwuqssqkaieqge(__("\x41\160\x70\x6c\x69\x63\141\x74\x69\157\x6e\163", PR__CST__FILEFOX))->guiaswksukmgageq(__("\101\x70\160\x6c\151\143\x61\164\x69\157\156", PR__CST__FILEFOX))->gucwmccyimoagwcm(__("\101\x70\x70\154\151\143\x61\x74\151\x6f\x6e\x20\146\157\162\x20\160\162\157\x64\165\143\x74\163", PR__CST__FILEFOX)); } }

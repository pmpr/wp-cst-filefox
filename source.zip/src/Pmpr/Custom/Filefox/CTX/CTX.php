<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe450cfd             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Filefox\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Filefox\Container; class CTX extends Container { public function mameiwsayuyquoeq() { Medium::symcgieuakksimmu(); Material::symcgieuakksimmu(); Category::symcgieuakksimmu(); Application::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\145\162\155\137\x6c\151\x6e\153", [$this, "\153\165\x63\x73\x79\x6f\x6f\141\141\161\x69\x73\x65\x65\x77\145"], 999, 2); } public function kucsyooaaqiseewe($iwywmkygwewiamwm, $iwewcwusemqaiggk) { $kesssewsiegssiya = $this->caokeucsksukesyo()->kckogqkiycqeumoa()->yyoeeseewqmmyaee($iwewcwusemqaiggk, Constants::ckmqoekmugkggeym); if ($this->caokeucsksukesyo()->yyoeeseewqmmyaee()->cekoogweeooasayu($kesssewsiegssiya)) { goto uegouoiuyoqkcscg; } $iwywmkygwewiamwm = ''; uegouoiuyoqkcscg: return $iwywmkygwewiamwm; } }
